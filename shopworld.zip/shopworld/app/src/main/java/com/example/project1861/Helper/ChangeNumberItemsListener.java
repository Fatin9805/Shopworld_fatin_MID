package com.example.project1861.Helper;

public interface ChangeNumberItemsListener {
    void changed();
}
